 <!DOCTYPE html> 
<html lang="pt-br">
	<head>
		<link rel="stylesheet" type="text/css" href="css/estilo.css">
		<meta html lang="pt-br">
		<meta charset='UTF-8'>
		<title>Estrutura - PI II</title>
	</head>
	
	<body>
		<header>
			<nav id="menu">
				<ul>
				  <li><a href="index.php" class="nav-item">Home</a></li>
				  <li><a href="area/index.php" class="nav-item">Área</a></li>
				  <li><a href="assunto/index.php" class="nav-item">Assunto</a></li>
				  <li><a href="questao/index.php" class="nav-item">Questão</a></li>
				</ul>
			</nav>
		</header>	

		<div id="section">




			<img class="img"src="img/logo.png" alt="Logo SenaQuiz" height="330" width="400">

			<h2>Bem vindo ao SenaQuiz!</h2>

			<p class="txt1">O SenaQuiz é um jogo de perguntas e respostas, onde você poderá inserir, alterar, editar e apagar qualquer informação referente ao jogo.</p>

		
			<!--	<p class="txt2">Na opção <strong>Área </strong>você poderá cadastrar uma Àrea de sua escolha, para alocar as questões relacionadas ao tema abordado.</p>

			<img class="img2"src="img/logo2.png" alt="Logo SenaQuiz" height="330" width="400">
			-->


		</div>
			
		<div id="footer"></div>
	</body>
</html>