 <!DOCTYPE html> 
<html lang="pt-br">
	<head>
		<link rel="icon" type="image/png" sizes="16x16" href="../img/logopag.png">
		<link rel="stylesheet" type="text/css" href="css/estilo.css">
		<meta html lang="pt-br">
		<meta charset='UTF-8'>

		<title>Estrutura - PI II</title>
	
		<script type="text/javascript">
			
		function Mudarestado(el) {
    		var display = document.getElementById(el).style.display;

    if(display == "none")
        document.getElementById(el).style.display = 'block';
    else
        document.getElementById(el).style.display = 'none';
}	

		</script>

	
	</head>
	
	<body>
		<header>
			<nav id="menu">
				<ul>
				  <li><a href="index.php" class="nav-item">Home</a></li>
				  <li><a href="area/index.php" class="nav-item">Área</a></li>
				  <li><a href="assunto/index.php" class="nav-item">Assunto</a></li>
				  <li><a href="questao/index.php" class="nav-item">Questão</a></li>
				  <li><a href="questao/index.php" class="nav-item">Professor</a></li>
				</ul>
			</nav>
		</header>	
	<div id="section">
	<div id="textos">
			<div id="txt1">esse é o texto1</div>

			<div id="txt2">esse é o texto2</div>

			<div id="txt3">esse é o texto3</div>
	
			<div id="txt4">esse é o texto4</div>

			<div id="txt5">esse é o texto5</div>
	
	</div>
	</div>


	<div id="container">

	

			<input type="radio" id="foto1" name="grupo" checked onclick="Mudarestado('txt1')"Mostrar/Esconder>
			<label for="foto1"><img src="img/logo.png" ></label>

			<input type="radio" id="foto2" name="grupo" onclick="Mudarestado('txt2')"Mostrar/Esconder>>
			<label for="foto2"><img src="img/area.png"></label>

			<input type="radio" id="foto3" name="grupo" onclick="Mudarestado('txt3')"Mostrar/Esconder>>
			<label for="foto3"><img src="img/assunto.png"></label>

			<input type="radio" id="foto4" name="grupo" onclick="Mudarestado('txt4')"Mostrar/Esconder>>
			<label for="foto4"><img src="img/questao.png"></label>

			<input type="radio" id="foto5" name="grupo" onclick="Mudarestado('txt5')"Mostrar/Esconder>>
			<label for="foto5"><img src="img/professor.png"></label>


			<div class="principal">
			<div class="slide">

		<img src="img/logo.png" width="480" height="350" >
		<img src="img/area.png" width="480" height="400" >	
		<img src="img/assunto.png" width="480" height="300">
		<img src="img/questao.png" width="480" height="350">
		<img src="img/professor.png" width="480" height="400">


</div>
	</div>
		</div>

		<div id="footer"></div>



	
		<!-- img1- logosenac
		img2 - area
		img3 - assunto
		img4 - questao
		img5 - professor -->

	</body>
</html>