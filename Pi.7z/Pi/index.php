 <!DOCTYPE html> 
<html lang="pt-br">
	<head>
		<link rel="stylesheet" type="text/css" href="css/estilo.css">
		<meta html lang="pt-br">
		<meta charset='UTF-8'>
		<title>Estrutura - PI II</title>
	</head>
	
	<body>
		<header>
			<nav id="menu">
				<ul>
				  <li><a href="index.php" class="nav-item">Home</a></li>
				  <li><a href="area/index.php" class="nav-item">Área</a></li>
				  <li><a href="assunto/index.php" class="nav-item">Assunto</a></li>
				  <li><a href="questao/index.php" class="nav-item">Questão</a></li>
				  <li><a href="questao/index.php" class="nav-item">Professor</a></li>
				</ul>
			</nav>
		</header>	


			
		<div id="footer"></div>
	</body>
</html>